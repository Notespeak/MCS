import createWebWorker from "./lib/modules/viewUpdater.js";

createWebWorker("camera");
