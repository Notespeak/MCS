import createWebWorker from "./lib/modules/viewUpdaterPrinterMap.js";

createWebWorker("panel");
