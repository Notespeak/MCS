// jest.config.js
module.exports = {
  testEnvironment: "node",
  testTimeout: 5000
};
